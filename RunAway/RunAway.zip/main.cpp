//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TVar::TVar()//: TVar(Owner)
{
	NumDays=00;
	MaxDays=100;
	MaxVals=100;
	for (int j = 0; j < MaxDays; j++)
	{
		NumVals[j]=0;
		Dimension[j]=0;
		TypeVar[j]=0;
		for (int i = 0; i < MaxVals; i++)
		{
			IntValue[j][i]=0;
			DateValue[j][i]=Now();
		}
	}
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
	MaxVars=100;
	NumVars=0;
	FiveMinMode=false;
	Mode=-1;

	SourcesDirectory=ExtractFilePath(Application->ExeName)+"sources\\";
	ReportsDirectory=ExtractFilePath(Application->ExeName)+"reports\\";
	SourceRunAwayKFileName="������_�_�";
	SourceRunAwayTFileName="������_�_��";
	SourceRunAwayPFileName="������_����";
	SourceRunAwayKPSFileName="������_�_���";

	FullSourceRunAwayKFileName=SourcesDirectory+SourceRunAwayKFileName;
	FullSourceRunAwayTFileName=SourcesDirectory+SourceRunAwayTFileName;
	FullSourceRunAwayPFileName=SourcesDirectory+SourceRunAwayPFileName;
	FullSourceRunAwayKPSFileName=SourcesDirectory+SourceRunAwayKPSFileName;


	SourceRunAwayFileName=DefaultSourceRunAwayFileName;

	CreateDirectory(SourcesDirectory.c_str(), NULL);
	CreateDirectory(ReportsDirectory.c_str(), NULL);

	FileListBox1->Mask="*.*";
	FileListBox1->Directory=SourcesDirectory;

	if (FileListBox1->Count>0) DefaultSourceRunAwayFileName=FileListBox1->Items->Strings[0];
	Edit1->Text=SourcesDirectory+DefaultSourceRunAwayFileName;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
	Form1->Close();
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
void __fastcall TForm1::ReadSourceFile(AnsiString FileName, int NDay)
{
	Memo1->Clear();
	for (int i=0; i<MaxVars; i++)
	{
		Vars[i].NameVar[NDay]="";
		Vars[i].Dimension[NDay]=0;
		Vars[i].NumVals[NDay]=0;
		for (int j=0; j<Vars[i].MaxVals; j++)
		{
			Vars[i].IntValue[NDay][j]=0;
		}
	}

	const int MaxBytes=65536;
	int ByteCodeChars[MaxBytes];
	int BytePosChars[MaxBytes];
	const int MaxWords=32768;
	int WordCodeChars[MaxWords];
	int WordPosChars[MaxWords];
	const int MaxDWords=16384;
	int DWordCodeChars[MaxDWords];
	int DWordPosChars[MaxDWords];

	for (int i=0; i<MaxBytes; i++)
	{
		ByteCodeChars[i]=0;
		BytePosChars[i]=0;
	}
	for (int i=0; i<MaxWords; i++)
	{
		WordCodeChars[i]=0;
		WordPosChars[i]=0;
	}
	for (int i=0; i<MaxDWords; i++)
	{
		DWordCodeChars[i]=0;
		DWordPosChars[i]=0;
	}
	int iFileHandle;
	AnsiString st, st1;
	st="";
	char c1=1;
	BYTE B=0;
	Word W=0, W1=0, W2=0;
	DWORD DW=0, DW1=0, DW2=0;
	Word w10=10;
	Word w13=13;
	Word w32=32;
	UnicodeString ust="";
	UnicodeString USt1="";
	UnicodeString TypeFile="";
	UnicodeString TypesFile[4];
	TypesFile[0]="������_�_�";
	TypesFile[1]="������_�_��";
	TypesFile[2]="������_����";
	TypesFile[3]="������_�_���";
	int NumTypesFile=4;

	Mode=-1;

	if (FileExists(FileName))
	{
		iFileHandle = FileOpen(FileName,fmOpenRead);
	}
	int iFileLength;
	int iBytesRead;

	int BytesRead;
	int WordsRead;
	int DWordsRead;

	BYTE *ByteBuffer;
	Word *WordBuffer;
	DWORD *DWordBuffer;
	if (iFileHandle)
	{

		iFileLength = FileSeek(iFileHandle,0,2);

		int ByteLength=iFileLength+1;
		ByteBuffer = new BYTE[ByteLength];

		int WordLength=iFileLength/2+1;
		WordBuffer = new Word[WordLength];

		int DWordLength=iFileLength/4+1;
		DWordBuffer = new DWORD[DWordLength];

		FileSeek(iFileHandle,0,0);
		iBytesRead = FileRead(iFileHandle, ByteBuffer, iFileLength);
		BytesRead=iBytesRead;

		FileSeek(iFileHandle,0,0);
		iBytesRead = FileRead(iFileHandle, WordBuffer, iFileLength);
		WordsRead=iBytesRead/2;

		FileSeek(iFileHandle,0,0);
		iBytesRead = FileRead(iFileHandle, DWordBuffer, iFileLength);
		DWordsRead=iBytesRead/4;

		for (int i = 88/2; i < (88+64)/2; i++)
		{
			if (i>=WordsRead) break;
			W=((Word)WordBuffer[i]);
			if (W!=0)
			{
				TypeFile.operator +=((wchar_t)W);
			}
		}
		for (int i = 0; i < NumTypesFile; i++)
		{
			if (!TypesFile[i].Compare(TypeFile))
			{
				Mode=i;
			}
		}
	}
	if (Mode!=-1)
	{
		NumVars=0;
		for (int i = 0; i < DWordsRead; i++)
		{
			int AddVar=-1;
			DW2=DW1;
			DW1=DW;
			DW=((DWord)DWordBuffer[i]);
			if ((DW1==4)&&(DW==8)) AddVar=0;
			if ((DW1==1)&&(DW==8)) AddVar=0;
			if ((DW1==7)&&(DW==8)) AddVar=1;
			if (AddVar!=-1)
			{
				W1=0;
				USt1="";
				int j = (i+1)*2;
				int n=0;
				while ((n<48)&&((j+n)<WordsRead))
				{
					W1=((Word)WordBuffer[j+n]);
					if ((W1!=0))
					{
						USt1.operator +=((wchar_t)W1);
					}
					n++;
				}
				if (USt1.Length()>0)
				{
					if (NumVars<MaxVars)
					{
						W1=0;
						j = j+48;
						int n=0;
						while ((n<60)&&((j+n)<WordsRead))
						{
							W1=((Word)WordBuffer[j+n]);
							if ((W1==102)||(W1==100)||(W1==109)||(W1==121))//||(W1==45))
							{
								Vars[NumVars].Dimension[NDay]++;
							}
							n++;
						}
						Vars[NumVars].NameVar[NDay]=USt1;
						Vars[NumVars].TypeVar[NDay]=AddVar;
						NumVars++;
					}
				}
			}
		}

		int ValsAdr=-1;
/*		for (int i = 0; i < DWordsRead; i++)
		{
			DW2=DW1;
			DW1=DW;
			DW=((DWord)DWordBuffer[i]);
			if ((DW1==2097245))
			{
			   //	ValsAdr=i*2;
			}
			if ((DW1==2097245)&&(DW==45))
			{
				ValsAdr=i*4+16;
			}
		}*/
		for (int i = 0; i < WordsRead; i++)
		{
			W2=W1;
			W1=W;
			W=((Word)WordBuffer[i]);
			if ((W2==93)&&(W1==32)&&(W==45))
			{
				ValsAdr=i*2+16;
			}
		}
		int Offset=0;
		if (ValsAdr!=-1)
		{
			for (int h = 0; h < 24; h++)
			{
				for (int i = 0; i < NumVars; i++)
				{
					if ((i==15)) Offset+=2;
					if ((i==32)) Offset+=2;
					if (Vars[i].TypeVar[NDay]==0)
					{
						if (Vars[i].Dimension[NDay]==2)
						{
							int adr=(ValsAdr+Offset)/2;
							if (adr<WordsRead)
							{
								W=((Word)WordBuffer[adr]);
								Vars[i].IntValue[NDay][h]=W;
								Vars[i].NumVals[NDay]++;
							}
						}
						if (Vars[i].Dimension[NDay]==4)
						{
							int adr=(ValsAdr+Offset)/2;
							if (adr<WordsRead)
							{
								DW=(DWord)((DWord)WordBuffer[adr]+(DWord)(WordBuffer[adr+1]*65536));
								Vars[i].IntValue[NDay][h]=DW;
								Vars[i].NumVals[NDay]++;
							}
						}
					}
					if (Vars[i].TypeVar[NDay]==1)
					{
						if (Vars[i].Dimension[NDay]==8)
						{
							int adr=(ValsAdr+Offset)/2;
							DW=(DWord)((DWord)WordBuffer[adr]+(DWord)(WordBuffer[adr+1]*65536));
							UINT ui1=(UINT)(65536*65535)+65535;
							UINT ui2=60*60*24*1000;
							double d48=(double)((double)ui1/(double)ui2);
							int ddt=DW*d48;
							DW=(DWord)((DWord)WordBuffer[adr]+(DWord)(WordBuffer[adr+3]*65536));
							Vars[i].IntValue[NDay][h]=DW;
							Vars[i].IntValue[NDay][h]/=1000;
							Vars[i].IntValue[NDay][h]/=60;
							Vars[i].IntValue[NDay][h]/=60;
							Vars[i].IntValue[NDay][h]/=24;

							TDateTime dt;
							dt.operator =(25569);
							dt.operator +=(ddt);
							dt.operator +=(Vars[i].IntValue[NDay][h]);
							Vars[i].DateValue[NDay][h]=dt;
							int pos=FileName.Pos(".");
							AnsiString y=FileName.SubString(pos+1,2);
							AnsiString m=FileName.SubString(pos+3,2);
							AnsiString d=FileName.SubString(pos+5,2);
							AnsiString hour=FileName.SubString(pos+7,2);
							AnsiString min=FileName.SubString(pos+9,2);
							AnsiString sec=FileName.SubString(pos+11,2);
							dt=StrToDateTime(d+"."+m+"."+y+" "+hour+":"+min+":"+sec);
							Vars[i].DateValue[NDay][h]=dt;
						}
					}
					Offset+=Vars[i].Dimension[NDay];
				}
				if (Mode==0) Offset+=12;
				if (Mode==1) Offset+=12;
				if (Mode==2) Offset+=12;
				if (Mode==3) Offset+=14;
			}
		}

		delete [] ByteBuffer;
		delete [] WordBuffer;
		delete [] DWordBuffer;
		FileClose(iFileHandle);

		for (int i=0; i<MaxVars; i++)
		{
			Vars[i].NumDays=NDay+1;
		}
	}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ShowReport(int NDay)
{
	if ((NumVars>0)&&(Vars[0].NumDays>0))
	{
		int	StartDay=0;
		int	FinishDay=0;
		if (NDay==-1)
		{
			StartDay=0;
			FinishDay=Vars[0].NumDays-1;
		}
		else
		{
			if ((NDay>=0)&&(NDay<Vars[0].NumDays))
			{
				StartDay=NDay;
				FinishDay=NDay;
			}
		}

			AnsiString TimeString1=Vars[2].DateValue[FinishDay][Vars[0].NumVals[FinishDay]-1].TimeString();
			AnsiString TS1= TimeString1.SubString(0,1);
			TDateTime DT1;
			if (TS1.AnsiCompareIC("0")==0)
			{
				DT1=Vars[2].DateValue[FinishDay][Vars[0].NumVals[FinishDay]-1]-1;
			}
			else
			{
				DT1=Vars[2].DateValue[FinishDay][Vars[0].NumVals[FinishDay]-1];
			}
			AnsiString DTString1=DT1.DateString();
			TS1= DTString1.SubString(4,2);

			AnsiString TimeString2=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1].TimeString();
			AnsiString TS2= TimeString2.SubString(0,1);
			TDateTime DT2;
			if (TS2.AnsiCompareIC("0")==0)
			{
				DT2=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1]-1;
			}
			else
			{
				DT2=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1];
			}
			AnsiString DTString2=DT2.DateString();
			TS2= DTString2.SubString(4,2);
			if (TS2.AnsiCompareIC(TS1)==0)
			{
			}
			else
			{
				StartDay++;
			}

		UnicodeString ust="";
		ust.operator +=((wchar_t)9);
		ust.operator +=((wchar_t)9);
		ust.operator +=((wchar_t)9);
		if (Mode==0) ust.operator +=("���������� ����������� ���� �� ������� � �������");
		if (Mode==1) ust.operator +=("���������� ����������� ���� ����� �� � �������");
		if (Mode==2) ust.operator +=("���������� �������� ����������� ���� � �������");
		if (Mode==3) ust.operator +=("���������� ����������� ���� � ���");
		ust.operator +=((wchar_t)13);
		ust.operator +=((wchar_t)10);
		if (StartDay==FinishDay)
		{
			ust.operator +=((wchar_t)9);
			ust.operator +=((wchar_t)9);
			ust.operator +=((wchar_t)9);
			ust.operator +=((wchar_t)9);
			ust.operator +=((wchar_t)9);
			ust.operator +=("�� �����");
//		ust.operator +=(" �� ����� � ");
			ust.operator +=("  ");
			AnsiString TimeString=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1].TimeString();
			AnsiString TS= TimeString.SubString(0,1);
			TDateTime DT;
			if (TS.AnsiCompareIC("0")==0)
			{
				DT=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1]-1;
			}
			else
			{
				DT=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1];
			}
			AnsiString DTString=DT.DateString();
			ust.operator +=(DTString);
		}
		else
		{
			ust.operator +=((wchar_t)9);
			ust.operator +=((wchar_t)9);
			ust.operator +=((wchar_t)9);
			ust.operator +=((wchar_t)9);
			ust.operator +=(" �� ������ � ");
			AnsiString TimeString=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1].TimeString();
			AnsiString TS= TimeString.SubString(0,1);
			TDateTime DT;
			if (TS.AnsiCompareIC("0")==0)
			{
				DT=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1]-1;
			}
			else
			{
				DT=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1];
			}
			AnsiString DTString=DT.DateString();
			ust.operator +=(DTString);
			ust.operator +=("  ��  ");

			TimeString=Vars[2].DateValue[FinishDay][Vars[0].NumVals[FinishDay]-1].TimeString();
			TS= TimeString.SubString(0,1);
			if (TS.AnsiCompareIC("0")==0)
			{
				DT=Vars[2].DateValue[FinishDay][Vars[0].NumVals[FinishDay]-1]-1;
			}
			else
			{
				DT=Vars[2].DateValue[FinishDay][Vars[0].NumVals[FinishDay]-1];
			}
			DTString=DT.DateString();
			ust.operator +=(DTString);

		}
		ust.operator +=((wchar_t)13);
		ust.operator +=((wchar_t)10);
		ust.operator +=((wchar_t)13);
		ust.operator +=((wchar_t)10);
		int col=0;
		int row=0;
		int cols=0;
		if (Mode==0) cols=5;
		if (Mode==1) cols=5;
		if (Mode==2) cols=2;
		if (Mode==3) cols=4;
		for (int i=3; i<NumVars; i++)
		{
			if (col==0)
			{
				if (Mode==0)
				{
					if (row==0)
					{
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("����� 537");
						ust.operator +=((wchar_t)9);
						ust.operator +=("546 - 550");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("550 - 555");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("555 - 560");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("����� 560");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
					}
					if (row==7)
					{
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("����� 545");
						ust.operator +=((wchar_t)9);
						ust.operator +=("556 - 560");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("560 - 565");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("565 - 570");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("����� 570");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
					}
				}
				if (Mode==1)
				{
					if (row==0)
					{
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("����� 535");
						ust.operator +=((wchar_t)9);
						ust.operator +=("546 - 550");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("550 - 555");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("555 - 560");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("����� 560");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
					}
					if (row==6)
					{
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("����� 540");
						ust.operator +=((wchar_t)9);
						ust.operator +=("556 - 560");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("560 - 565");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("565 - 570");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("����� 570");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
					}
				}
				if (Mode==2)
				{
					if (row==0)
					{
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("����� 115");
						ust.operator +=((wchar_t)9);
						ust.operator +=("����� 130");
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
					}
					if (row==9)
					{
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("����� 120");
						ust.operator +=((wchar_t)9);
						ust.operator +=("����� 135");
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
					}
				}
				if (Mode==3)
				{
					if (row==0)
					{
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("546 - 550");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("550 - 555");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("555 - 560");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("����� 560");
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
					}
					if (row==11)
					{
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("556 - 560");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("560 - 565");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("565 - 570");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("����� 570");
						ust.operator +=((wchar_t)13);
						ust.operator +=((wchar_t)10);
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("----------------------------------------------------------------------------------------------------------------");
					}
				}
			}
//			ust.operator +=(Vars[i].NameVar);
//			ust.operator +=((wchar_t)9);
			col++;
			if (col>=cols)
			{
				col=0;
				ust.operator +=((wchar_t)13);
				ust.operator +=((wchar_t)10);
				ust.operator +=((wchar_t)13);
				ust.operator +=((wchar_t)10);
				if (Mode==0)
				{
					if (row==0)
					{
						ust.operator +=("����� ��.�3");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==1)
					{
						ust.operator +=("����� ��.�4");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==2)
					{
						ust.operator +=("����� ��.�5");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==3)
					{
						ust.operator +=("����� ��.�6");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==4)
					{
						ust.operator +=("����� ��.�7");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==5)
					{
						ust.operator +=("����� ��.�8");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==6)
					{
						ust.operator +=("����� ��.�9");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==7)
					{
						ust.operator +=("����� ��.�10");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==8)
					{
						ust.operator +=("����� ��.�11");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
				}
				if (Mode==1)
				{
					if (row==0)
					{
						ust.operator +=("�/� 2 �����");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==1)
					{
						ust.operator +=("�/� 2 ������");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==2)
					{
						ust.operator +=("�/� 3 �����");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==3)
					{
						ust.operator +=("�/� 3 ������");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==4)
					{
						ust.operator +=("�/� 4 �����");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==5)
					{
						ust.operator +=("�/� 4 ������");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==6)
					{
						ust.operator +=("�/� 5");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==7)
					{
						ust.operator +=("�/� 6");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
				}
				if (Mode==2)
				{
					if (row==0)
					{
						ust.operator +=("��� �.1");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==1)
					{
						ust.operator +=("��� �.2");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==2)
					{
						ust.operator +=("��� �.3");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==3)
					{
						ust.operator +=("�/� 2 �����");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==4)
					{
						ust.operator +=("�/� 2 ������");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==5)
					{
						ust.operator +=("�/� 3 �����");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==6)
					{
						ust.operator +=("�/� 3 ������");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==7)
					{
						ust.operator +=("�/� 4 �����");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==8)
					{
						ust.operator +=("�/� 4 ������");
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==9)
					{
						ust.operator +=("��� �.4");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==10)
					{
						ust.operator +=("��� �.5");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==11)
					{
						ust.operator +=("�/� 5");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==12)
					{
						ust.operator +=("�/� 6");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
				}
				if (Mode==3)
				{
					if (row==0)
					{
						ust.operator +=("����� 1");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==1)
					{
						ust.operator +=("����� 2");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==2)
					{
						ust.operator +=("����� 3");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==3)
					{
						ust.operator +=("����� 4");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==4)
					{
						ust.operator +=("����� 5");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==5)
					{
						ust.operator +=("����� 6");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==6)
					{
						ust.operator +=("����� 7");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==7)
					{
						ust.operator +=("����� 8");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==8)
					{
						ust.operator +=("����� 9");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==9)
					{
						ust.operator +=("����� 10");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==10)
					{
						ust.operator +=("����� 11");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==11)
					{
						ust.operator +=("����� 12");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
					if (row==12)
					{
						ust.operator +=("����� 13");
						ust.operator +=((wchar_t)9);
						ust.operator +=((wchar_t)9);
						ust.operator +=("|");
					}
				}
				for (int j=cols-1; j>=0; j--)
				{
					int val=0;
					for (int d=StartDay; d<=FinishDay; d++)
					{
						for (int h=0; h<Vars[i].NumVals[d]; h++)
						{
							if ((Vars[i-j].IntValue[d][h]>=5)||(!FiveMinMode))
							{
								val+=Vars[i-j].IntValue[d][h];
							}
						}
					}
					ust.operator +=((wchar_t)9);
					ust.operator +=(val);
					ust.operator +=((wchar_t)9);
				}
				ust.operator +=((wchar_t)13);
				ust.operator +=((wchar_t)10);
				row++;
			}
		}
		ust.operator +=((wchar_t)13);
		ust.operator +=((wchar_t)10);

  /*		for (int i=0; i<NumVars; i++)
		{
			ust.operator +=("Var: ");
			ust.operator +=(Vars[i].NameVar);
			ust.operator +=((wchar_t)9);
			ust.operator +=("Dim: ");
			ust.operator +=(Vars[i].Dimension);
			ust.operator +=((wchar_t)9);
			ust.operator +=("Vals: ");
			ust.operator +=((wchar_t)32);
			for (int j = 0; j < Vars[i].NumVals; j++)
			{
				ust.operator +=(Vars[i].IntValue[j]);
				ust.operator +=((wchar_t)32);
			}
			ust.operator +=((wchar_t)13);
			ust.operator +=((wchar_t)10);
		}                     */


		Memo1->Text=ust;
		int l=Memo1->Text.Length();
		l=Memo1->Text.Length();
	}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
	OpenDialog1->InitialDir=SourcesDirectory;
	OpenDialog1->Filter = "����� ������� �|������_�_�.*|����� ������� ��|������_�_��.*|��� ����� (*.*)|*.*";
	if (OpenDialog1->Execute())
		if (FileExists(OpenDialog1->FileName))
			SourceRunAwayFileName=OpenDialog1->FileName;
	else
		throw(Exception("File does not exist."));
	Edit1->Text=SourceRunAwayFileName;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
	ReadSourceFile(Edit1->Text,0);
	ShowReport(-1);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FileListBox1Click(TObject *Sender)
{
	DefaultSourceRunAwayFileName=FileListBox1->Items->Strings[FileListBox1->ItemIndex];
	Edit1->Text=SourcesDirectory+DefaultSourceRunAwayFileName;
	ReadSourceFile(Edit1->Text,0);
	ShowReport(-1);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton3Click(TObject *Sender)
{
	if (RadioButton3->Checked)
	{
		FileListBox1->Mask=SourceRunAwayPFileName+"*.*";
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton4Click(TObject *Sender)
{
	if (RadioButton4->Checked)
	{
		FileListBox1->Mask=SourceRunAwayKPSFileName+"*.*";
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton2Click(TObject *Sender)
{
	if (RadioButton2->Checked)
	{
		FileListBox1->Mask=SourceRunAwayTFileName+"*.*";
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton1Click(TObject *Sender)
{
	if (RadioButton1->Checked)
	{
		FileListBox1->Mask=SourceRunAwayKFileName+"*.*";
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton5Click(TObject *Sender)
{
	if (RadioButton5->Checked)
	{
		FileListBox1->Mask="*.*";
	}
}
//---------------------------------------------------------------------------


void __fastcall TForm1::CheckBox1Click(TObject *Sender)
{
	FiveMinMode=CheckBox1->Checked;
	ShowReport(-1);
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button4Click(TObject *Sender)
{
	ExportReport(-1);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button5Click(TObject *Sender)
{
	if (FileListBox1->ItemIndex>=0)
	{
	AnsiString St, StY, StM, StD, StType;
	AnsiString SelSt, SelStY, SelStM, SelStD, SelStType;
	SelSt=FileListBox1->Items->Strings[FileListBox1->ItemIndex];
	int pos=SelSt.Pos(".");
	SelStType=SelSt.SubString(1,pos-1);//.c_str();
	SelStY=SelSt.SubString(pos+1,2);
	SelStM=SelSt.SubString(pos+3,2);
	SelStD=SelSt.SubString(pos+5,2);
	int SelY=SelStY.ToInt();
	int SelM=SelStM.ToInt();
	int SelD=SelStD.ToInt();
	int NumItems=FileListBox1->Count;
	int n=0;
	for (int i=0;i<NumItems;i++)
	{
		St=FileListBox1->Items->Strings[i];
		int pos=St.Pos(".");
		StType=St.SubString(1,pos-1);
		if (SelStType.AnsiCompareIC(StType)==0)
		{
			StY=St.SubString(pos+1,2);
			StM=St.SubString(pos+3,2);
			StD=St.SubString(pos+5,2);
			int Y;
			int M;
			int D;
			try
			{
				Y=StY.ToInt();
				M=StM.ToInt();
				D=StD.ToInt();
			}
			catch(...)
			{
				Y=0;
				M=0;
				D=0;
			}
			if ((SelY==Y)&&(SelM==M))
			{
				AnsiString FileName=SourcesDirectory+St;
				ReadSourceFile(FileName,n);
				n++;
			}
		}
	}
	ShowReport(-1);
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ExportReport(int NDay)
{
if (Mode!=-1)
{
	SetCurrentDir(ExtractFilePath(Application->ExeName));
	Variant v;
	if(!fStart)
	{
		try
		{
			vVarApp=CreateOleObject("Excel.Application");
			fStart=true;
		}
		catch(...)
		{
			MessageBox(0, "������ ��� �������� ������� Excel",
				 "������", MB_OK);
			return;
		}
		vVarApp.OlePropertySet("Visible",true);
//		vVarApp.OlePropertySet("Visible",false);
		vVarBooks=vVarApp.OlePropertyGet("Workbooks");
		vVarApp.OlePropertySet("SheetsInNewWorkbook",1);
		vVarBooks.OleProcedure("Add");

		vVarBook=vVarBooks.OlePropertyGet("Item",1);
		vVarSheets=vVarBook.OlePropertyGet("Worksheets") ;

		AnsiString st, st1;

		int	StartDay=0;
		int	FinishDay=0;
		int	ND=1;

		if (NDay==-1)
		{
			StartDay=0;
			FinishDay=Vars[0].NumDays-1;
			if (StartDay==FinishDay)
			{
				NDay=FinishDay;
			}
			else
			{
				NDay=FinishDay;
			}
		}
		else
		{
			if ((NDay>=0)&&(NDay<Vars[0].NumDays))
			{
				StartDay=NDay;
				FinishDay=NDay;
				NDay=StartDay;
			}
		}
//jjjjjjjjjjjjjjjjjjjjjjjjjjj
			AnsiString TimeString1=Vars[2].DateValue[FinishDay][Vars[0].NumVals[FinishDay]-1].TimeString();
			AnsiString TS1= TimeString1.SubString(0,1);
			TDateTime DT1;
			if (TS1.AnsiCompareIC("0")==0)
			{
				DT1=Vars[2].DateValue[FinishDay][Vars[0].NumVals[FinishDay]-1]-1;
			}
			else
			{
				DT1=Vars[2].DateValue[FinishDay][Vars[0].NumVals[FinishDay]-1];
			}
			AnsiString DTString1=DT1.DateString();
			TS1= DTString1.SubString(4,2);

			AnsiString TimeString2=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1].TimeString();
			AnsiString TS2= TimeString2.SubString(0,1);
			TDateTime DT2;
			if (TS2.AnsiCompareIC("0")==0)
			{
				DT2=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1]-1;
			}
			else
			{
				DT2=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1];
			}
			AnsiString DTString2=DT2.DateString();
			TS2= DTString2.SubString(4,2);
			if (TS2.AnsiCompareIC(TS1)==0)
			{
			}
			else
			{
				StartDay++;
			}

		while (NDay>=(StartDay-1))
		{
		if ((NDay<StartDay)&&(StartDay==FinishDay)) break;
		if (ND>1) vVarSheets.OleProcedure("Add");
		vVarSheet=vVarSheets.OlePropertyGet("Item",1);

		if ((NDay<StartDay)&&(StartDay!=FinishDay))
		{
			st="�����";
		}
		else
		{

			AnsiString TimeString=Vars[2].DateValue[NDay][Vars[0].NumVals[NDay]-1].TimeString();
			AnsiString TS= TimeString.SubString(0,1);
			TDateTime DT;
			if (TS.AnsiCompareIC("0")==0)
			{
				DT=Vars[2].DateValue[NDay][Vars[0].NumVals[NDay]-1]-1;
			}
			else
			{
				DT=Vars[2].DateValue[NDay][Vars[0].NumVals[NDay]-1];
			}
			AnsiString DTString=DT.DateString();

			st=DTString+" "+NDay;



			TimeString=Vars[2].DateValue[NDay][Vars[1].NumVals[NDay]-1].TimeString();
			TS= TimeString.SubString(0,1);
			if (TS.AnsiCompareIC("0")==0)
			{
				DT=Vars[2].DateValue[NDay][Vars[1].NumVals[NDay]-1]-1;
			}
			else
			{
				DT=Vars[2].DateValue[NDay][Vars[1].NumVals[NDay]-1];
			}
			DT.Val--;
			DTString=DT.DateString();
			st1=DTString+" "+NDay;
		}

		try
		{
			vVarSheet.OlePropertySet("Name",st.c_str());
		}
		catch(...)
		{
			vVarSheet.OlePropertySet("Name",st1.c_str());
			Vars[2].DateValue[NDay][Vars[0].NumVals[NDay]-1].Val--;
		}
		vVarSheet.OleProcedure("Activate");

//		vVarSheet=vVarSheets.OlePropertyGet("Item",1);
		vVarCell=vVarSheet.OlePropertyGet("Range","A1:F1000");
		vVarCell.OlePropertySet("ColumnWidth",13);
		vVarCell.OlePropertySet("HorizontalAlignment",-4108);
		vVarCell.OlePropertySet("VerticalAlignment",-4108);
		vVarCell.OlePropertyGet("Font").OlePropertySet("Size",12);
		vVarCell.OlePropertyGet("Font").OlePropertySet("Name","Times New Roman");

		vVarCell=vVarSheet.OlePropertyGet("Range","A1:F1");
		vVarCell.OleProcedure("Merge");
		vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",1,1);

		if (Mode==0) st="���������� ����������� ���� �� ������� � �������";
		if (Mode==1) st="���������� ����������� ���� ����� �� � �������";
		if (Mode==2) st="���������� �������� ����������� ���� � �������";
		if (Mode==3) st="���������� ����������� ���� � ���";
		vVarCell.OlePropertySet("Value",st.c_str() );

		vVarCell=vVarSheet.OlePropertyGet("Range","A2:F2");
		vVarCell.OleProcedure("Merge");
		vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",2,1);
		if ((StartDay==FinishDay)||(NDay>(StartDay-1)))
		{
			st="�� ����� ";
			AnsiString TimeString=Vars[2].DateValue[NDay][Vars[0].NumVals[NDay]-1].TimeString();
			AnsiString TS= TimeString.SubString(0,1);
			TDateTime DT;
			if (TS.AnsiCompareIC("0")==0)
			{
				DT=Vars[2].DateValue[NDay][Vars[0].NumVals[NDay]-1]-1;
			}
			else
			{
				DT=Vars[2].DateValue[NDay][Vars[0].NumVals[NDay]-1];
			}
			AnsiString DTString=DT.DateString();
			st.operator +=(DTString);
			st.operator +=(" � ");
			st.operator +=(DT.TimeString());
		}
		else
		{
			st="�� ������ � ";
			AnsiString TimeString=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1].TimeString();
			AnsiString TS= TimeString.SubString(0,1);
			TDateTime DT;
			if (TS.AnsiCompareIC("0")==0)
			{
				DT=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1]-1;
			}
			else
			{
				DT=Vars[2].DateValue[StartDay][Vars[0].NumVals[StartDay]-1];
			}
			AnsiString DTString=DT.DateString();
			st.operator +=(DTString);
			st.operator +=("  ��  ");
			TimeString=Vars[2].DateValue[FinishDay][Vars[0].NumVals[FinishDay]-1].TimeString();
			TS= TimeString.SubString(0,1);
			if (TS.AnsiCompareIC("0")==0)
			{
				DT=Vars[2].DateValue[FinishDay][Vars[0].NumVals[FinishDay]-1]-1;
			}
			else
			{
				DT=Vars[2].DateValue[FinishDay][Vars[0].NumVals[FinishDay]-1];
			}
			DTString=DT.DateString();
			st.operator +=(DTString);
		}
		vVarCell.OlePropertySet("Value",st.c_str() );

		int col=0;
		int row=0;
		int row1=0;
		int cols=0;
		if (Mode==0){ cols=5; row1=7;}
		if (Mode==1){ cols=5; row1=6;}
		if (Mode==2){ cols=2; row1=9;}
		if (Mode==3){ cols=4; row1=11;}
		for (int i=3; i<NumVars; i++)
		{
			if (col==0)
			{
				if (Mode==0)
				{
					if (row==0)
					{
						st = "����� 537";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+2);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "545 - 550";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+3);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "550 - 555";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+4);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "555 - 560";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+5);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "����� 560";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+6);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
					}
					if (row==row1)
					{
						st = "����� 545";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+2);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "556 - 560";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+3);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "560 - 565";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+4);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "565 - 570";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+5);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "����� 570";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+6);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
					}
				}
				if (Mode==1)
				{
					if (row==0)
					{
						st = "����� 535";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+2);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "546 - 550";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+3);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "550 - 555";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+4);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "555 - 560";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+5);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "����� 560";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+6);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
					}
					if (row==row1)
					{
						st = "����� 540";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+2);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "556 - 560";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+3);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "560 - 565";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+4);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "565 - 570";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+5);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "����� 570";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+6);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
					}
				}
				if (Mode==2)
				{
					if (row==0)
					{
						st = "����� 115";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+2);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "����� 130";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+3);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
					}
					if (row==row1)
					{
						st = "����� 120";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+2);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "����� 135";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+3);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
					}
				}
				if (Mode==3)
				{
					if (row==0)
					{
						st = "546 - 550";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+2);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "550 - 555";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+3);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "555 - 560";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+4);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "����� 560";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+5,col+5);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
					}
					if (row==row1)
					{
						st = "556 - 560";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+2);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "560 - 565";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+3);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "565 - 570";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+4);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
						st = "����� 570";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,col+5);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
					}
				}
			}
			col++;
			if (col>=cols)
			{
				col=0;
				if (Mode==0)
				{
					if (row==0)
					{
						st = "����� ��.�3";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==1)
					{
						st = "����� ��.�4";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==2)
					{
						st = "����� ��.�5";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==3)
					{
						st = "����� ��.�6";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==4)
					{
						st = "����� ��.�7";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==5)
					{
						st = "����� ��.�8";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==6)
					{
						st = "����� ��.�9";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==7)
					{
						st = "����� ��.�10";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+7,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==8)
					{
						st = "����� ��.�11";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+7,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
				}
				if (Mode==1)
				{
					if (row==0)
					{
						st = "�/� 2 �����";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==1)
					{
						st = "�/� 2 ������";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==2)
					{
						st = "�/� 3 �����";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==3)
					{
						st = "�/� 3 ������";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==4)
					{
						st = "�/� 4 �����";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==5)
					{
						st = "�/� 4 ������";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==6)
					{
						st = "�/� 5";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+7,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==7)
					{
						st = "�/� 6";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+7,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
				}
				if (Mode==2)
				{
					if (row==0)
					{
						st = "��� �.1";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==1)
					{
						st = "��� �.2";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==2)
					{
						st = "��� �.3";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==3)
					{
						st = "�/� 2 �����";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==4)
					{
						st = "�/� 2 ������";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==5)
					{
						st = "�/� 3 �����";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==6)
					{
						st = "�/� 3 ������";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==7)
					{
						st = "�/� 4 �����";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==8)
					{
						st = "�/� 4 ������";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==9)
					{
						st = "��� �.4";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+7,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==10)
					{
						st = "��� �.5";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+7,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==11)
					{
						st = "�/� 5";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+7,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==12)
					{
						st = "�/� 6";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+7,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
				}
				if (Mode==3)
				{
					if (row==0)
					{
						st = "����� 1";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==1)
					{
						st = "����� 2";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==2)
					{
						st = "����� 3";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==3)
					{
						st = "����� 4";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==4)
					{
						st = "����� 5";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==5)
					{
						st = "����� 6";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==6)
					{
						st = "����� 7";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==7)
					{
						st = "����� 8";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==8)
					{
						st = "����� 9";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==9)
					{
						st = "����� 10";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==10)
					{
						st = "����� 11";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==11)
					{
						st = "����� 12";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+7,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",8).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (row==12)
					{
						st = "����� 13";
						vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+7,1);
						vVarCell.OlePropertySet("Value",st.c_str() );
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",7).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
				}
				for (int j=cols-1; j>=0; j--)
				{
					int val=0;
					if ((StartDay==FinishDay)||(NDay>(StartDay-1)))
					{
						for (int h=0; h<Vars[i].NumVals[NDay]; h++)
						{
							if ((Vars[i-j].IntValue[NDay][h]>=5)||(!FiveMinMode))
							{
								val+=Vars[i-j].IntValue[NDay][h];
							}
						}
					}
					else
					{
						for (int d=StartDay; d<=FinishDay; d++)
						{
							for (int h=0; h<Vars[i].NumVals[d]; h++)
							{
								if ((Vars[i-j].IntValue[d][h]>=5)||(!FiveMinMode))
								{
									val+=Vars[i-j].IntValue[d][h];
								}
							}
						}
					}
					int drow=0;
					if (row>=row1) drow=1;
					vVarCell=vVarSheet.OlePropertyGet("Cells").OlePropertyGet("Item",row+6+drow,cols-j+1);
					vVarCell.OlePropertySet("Value",val);
					if ((j!=0)&&((NumVars-(row+1)*cols)<=cols))
					{
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if ((j==0)&&((NumVars-(row+1)*cols)<=cols))
					{
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if ((j==0)&&!((NumVars-(row+1)*cols)<=cols))
					{
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",4);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
					if (!(j==0)&&!((NumVars-(row+1)*cols)<=cols))
					{
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",9).OlePropertySet("LineStyle",1);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("Weight",2);
vVarCell.OlePropertyGet("Borders",10).OlePropertySet("LineStyle",1);
					}
				}
				row++;
			}
			}
			ND++;
			NDay--;
//jjjjjjjjjjjjjjjjjjjjjjjjjjj
		}
		st=ReportsDirectory;
		if (Mode==0) st.operator +=(SourceRunAwayKFileName);
		if (Mode==1) st.operator +=(SourceRunAwayTFileName);
		if (Mode==2) st.operator +=(SourceRunAwayPFileName);
		if (Mode==3) st.operator +=(SourceRunAwayKPSFileName);
		if (StartDay==FinishDay)
		{
			st.operator +=(" �� ");
			AnsiString TimeString=Vars[2].DateValue[0][Vars[0].NumVals[0]-1].TimeString();
			AnsiString TS= TimeString.SubString(0,1);
			TDateTime DT;
			if (TS.AnsiCompareIC("0")==0)
			{
				DT=Vars[2].DateValue[0][Vars[0].NumVals[0]-1]-1;
			}
			else
			{
				DT=Vars[2].DateValue[0][Vars[0].NumVals[0]-1];
			}
			AnsiString DTString=DT.DateString();
			st.operator +=(DTString);
			st.operator +=(".xls");
		}
		else
		{
			st.operator +=(" �� ����� ");
			AnsiString TimeString=Vars[2].DateValue[FinishDay][Vars[0].NumVals[0]-1].TimeString();
			AnsiString TS= TimeString.SubString(0,1);
			TDateTime DT;
			if (TS.AnsiCompareIC("0")==0)
			{
				DT=Vars[2].DateValue[FinishDay][Vars[0].NumVals[0]-1]-1;
			}
			else
			{
				DT=Vars[2].DateValue[FinishDay][Vars[0].NumVals[0]-1];
			}
			AnsiString DTString=DT.DateString();
			st.operator +=(DTString);
			st.operator +=(".xls");
		}
		try
		{
			vVarApp.OlePropertyGet("Workbooks").OlePropertyGet("Item",1).OleProcedure("SaveAs", st.c_str());//"babam.xls");//
		}
		catch(...)
		{
			fStart=false;
			return;
		}
//		if(fStart) vVarApp.OleProcedure("Quit");
		fStart=false;
	}
}
}
